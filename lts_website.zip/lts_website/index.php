<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
	<meta name="description" content="Web developer located in Hartford County Connecticut" />
	<meta name="keywords" content="Web designer, web developer, Hartford, Bristol,Connecticut, CT,Ct,HTML,JavaScript, Jquery, Ajax, JSON, PHP, MySQL" />
    <title> </title>
    <link rel="stylesheet" href="styles/lts.css" type="text/css" />
    <script src="scripts/jquery-1.11.3.min.js"></script>
   <!-- <script src="scripts/     .js"></script> -->
  </head>
  <body>
	<?php
	if(isset($_POST['submit']))  {
		echo "Hello from Line 15";
		$to      =	"rmor191@yahoo.com";
		$subject =	$_POST['subject'];
		$from    =	$_POST['yourEmailAddress'];
		$text    =	$_POST['the_text'];
		$text    =	wordwrap($text, 70, "\r\n");
		$headers =  "From:"."$from"."\r\n";
		
		echo" $to.'<br>'.$subject.'<br>'.$from.'<br>'.$text.'<br>.$headers";
	
		mail($to, $subject, $text, $headers);
	
	} //End of isset submit.
	?>
	<div id="wrapper">
		<header>
			<div id="bbar">
				<h1>Lexton Technical Services</h1>
			</div>	
			<nav id=horizontal>
			
				<div id=home class=navbutton>
					Home
				</div>
				
				<div id=contact class=navbutton>
					Contact
				</div>
				
				<div id=about class=navbutton>
					<!-- About -->
					Background
				</div>
				<div id=web_development class=navbutton>
					<!--Web Development -->
					Examples
				</div>
				
			
			</nav>
			<div id=DropDown>
				<div id=History class="navbutton DropDownElem">
					<a id=WB_History href="downloads/webbasics.docx">History</a>
				</div>
					
				<div id=BAMS class="navbutton DropDownElem">BAMS</div>
				
				<div id=ViewMyAd class="navbutton DropDownElem">View My Ad</div>
			</div>
		
			<div id=FlyOutBAMS class=navbutton>
				<div id=BAMSliveSite  class="navbutton FlyOutBAMSelem">
					<a id=BAMSlive href=http://www.B-A-M-s.net>BAMS Live Site</a>
				</div>
				<div id=BAMSzip  class="navbutton FlyOutBAMSelem">  
					<a id=ziplink href="http://www.robertjmorelli.com/bams.zip"> BAMS Zip File </a>
				</div>
			</div>
		
			<div id=FlyOutviewMyAd class=navbutton>
				<div id=ViewMyAdliveSite class="navbutton ViewMyAdliveSiteelem">
					<a id=ViewMyAdlive href=http://www.View-My-Ad.com>View My Ad Live Site</a>
				</div>
				<div id=ViewMyAdzip  class="navbutton ViewMyAdliveSiteelem">  
					<a id=ziplink href="http://www.robertjmorelli.com/viewmyad.zip">View My Ad Zip File </a>
				</div>				
			</div>	
		
		
		
		
			<img src="images/city_of_hartford.jpg">
		
		</header>
		<div id=slogan>
				High quality web development at affordable prices
		</div>
		<section>
		<div id=results>
			
		</div>
			
		</section>
		
		
    </div>  <!-- End of Wrapper div. -->
	<script>
		$(document).ready(function() { 
			$("#results").load("my_html/home_page.htm");
			/* alert("script live");  */
			function clearSelected()  {
				$(".navbutton").css({"background-color":"#7D5D31"});
				/* Clear selected color (grey) from all buttons with navbutton class  -- Horizontal main menu buttons. */
			}
			function setSelected(inputDiv)  {
				inputDiv = "#" + inputDiv;
				$(inputDiv).css({"background-color":"#999999"});
			
			}
			function hideDiv(inputDiv)  {
				inputDiv = "#" + inputDiv;
				$(inputDiv).hide();
			}
			function hideAllDiv()  {
				hideDiv("FlyOutviewMyAd");
				hideDiv("FlyOutBAMS");
				hideDiv("DropDown");
			}
			
			
				$("#about").click(function() {
					$("#results").load("my_html/about.htm"); 
					 clearSelected();
					 setSelected("about");
					 hideAllDiv();
				}); 

				$("#home").click(function() {
					$("#results").load("my_html/home_page.htm"); 
					
					clearSelected();
					setSelected("home");
					hideAllDiv();
				});

				
				$("#contact").click(function() {
					$("#results").load("my_html/contact_form.htm"); 
					clearSelected();
					setSelected("contact");
					hideAllDiv();
				});
				
				
				
				
				$("#web_development").click(function() {
					$("#results").load("my_html/home_page.htm"); 
					clearSelected(); 
					setSelected("web_development");
					$("#DropDown").css({"display":"block"});
				});
				
				$("#History").click(function() {
					clearSelected();
					setSelected("History");
					hideAllDiv();
				});
				
				
				$("#BAMS").click(function() {
					clearSelected();
					setSelected("BAMS");
					$("#FlyOutBAMS").show();
					clearSelected();
					hideDiv("FlyOutviewMyAd");
				});
				
				$("#BAMSlive").click(function () {
					setSelected("BAMSliveSite");
					hideAllDiv();
				} );
				
				$("#BAMSlive").click(function () {
					setSelected("BAMSliveSite");
					hideAllDiv();
				} );
				
				
				
				$("#ViewMyAd").click(function() {
					clearSelected();
					setSelected("ViewMyAd");
					$("#FlyOutBAMS").hide();
					$("#FlyOutviewMyAd").show();
				});
				
				$("#ViewMyAdliveSite").click(function()  {
					clearSelected();
					setSelected("ViewMyAdliveSite");
					hideAllDiv();
				});
				
				$("#ViewMyAdzip").click(function()  {
					clearSelected();
					setSelected("ViewMyAdzip");
					hideAllDiv();
				});
				
				window.document.onkeydown = function (e)
				{
				if (!e) e = event;
					if (e.keyCode == 27) {
						/* alert('you have pressed ESC key'); */
						hideAllDiv();
						}
				}
				
				



    
				
	 });	
	</script>
	
  </body>
</html>
