
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LTS: Lexton Technical Services</title>
    <!-- Bootstrap core CSS -->
		<link href="css/bootstrap.css" rel="stylesheet">
		<!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
</head>

 <body>
<div class="jumbotron">
		<div class=container>

		<div id="bbar">
			<h1>Lexton Technical Services</h1>
			<h2>Web Developer in Bristol Connecticut</h2>
		</div>
		
<div class=header>
	 <nav class="navbar navbar-default">
    <!--  <div class="container"> -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="background.php">Background</a></li>
						<li><a href="example.php">Examples</a></li>
						<li><a href="links.php">Links</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<img id="slideshow333"	src="images/city_of_hartford.jpg">

<div id="slogan">
	<div	class="row">
		<div class=col-md-12>
			High quality web development at affordable prices
		</div>
	</div>
</div>

<div id="my_status_line">
	<div	class="row">
		<div class=col-md-12>
		
		</div>
	</div>
</div>


	<div id="area_div">
		<div	class="row">
			<div class=col-md-12>
					<div id="computer">
					<img src="images/mywebpagecomputer.png">   	
				</div> 
			</div> 
		</div>
	</div>
</div> <!-- End of Header -->	
	
</div>			
</div>	
	
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
   <!-- <script src="js/main.js"></script> -->
  </body>
</html>


    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script> -->


