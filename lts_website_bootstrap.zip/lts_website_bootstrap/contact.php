<?php
		date_default_timezone_set('America/New_York'); 
		$status_line = " ";
		$mail_response = " ";
		
	if(isset($_POST['submit']))  {
		$to =	"rmor191@yahoo.com";
		$subject = $_POST['subject'];
		$from =	trim($_POST['yourEmailAddress']);
		$text =	$_POST['the_text'];
		$text =	wordwrap($text, 70, "\r\n");
		$headers ="From:"."$from"."\r\n";
		if(mail($to,"Subject: $subject", $text, "From: $from")) {
			$mail_response = "mail has been sent" . " " . date("m/d/Y") . " " . date("h:i");
		}else {
			$mail_response = "mail has not been sent" . " " . date("m/d/Y") . " " . date("h:i");
		}
		 $status_line = $mail_response;
	}
?> 		
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LTS: Lexton Technical Services</title>
    <!-- Bootstrap core CSS -->
		<link href="css/bootstrap.css" rel="stylesheet">
		<!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
</head>
  <body>
	<div class="jumbotron">
		<div class=container>

	
	<div id="bbar">
			<h1>Lexton Technical Services</h1>
			<h2>Web Developer in Bristol Connecticut</h2>
		</div>
						
<div class=header>
	 <nav class="navbar navbar-default">
    <!--  <div class="container"> -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li class="active"><a href="contact.php">Contact</a></li>
            <li><a href="background.php">Background</a></li>
						<li><a href="example.php">Examples</a></li>
						<li><a href="links.php">Links</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
<img id="slideshow333"	src="images/city_of_hartford.jpg">


<div id="slogan">
	<div	class="row">
		<div class=col-md-12>
			High quality web development at affordable prices
		</div>
	</div>
</div>

<div id="my_status_line">
	<div	class="row">
		<div class=col-md-12>
	<?php echo "$status_line"; ?>	
		</div>
	</div>
</div>	
	
	<div id="area_div">
		<br><br><br>
		<!-- <div	class="row"> -->
		<form class="form-horizontal" id="contact_form" method="post" action="contact.php">
		<div	class="row">
			
				<!-- <label for="your_email" class="col-md-4 control-label">Your Email Address</label> -->
				<div class="col-md-4 col-sm-4">
					<input type="email" class="form-control" id="your_email" name="yourEmailAddress" placeholder="Your Email Address">
				</div>
			</div>
			<br>
			
			<div class="row">
			
				<!-- <label for="subject" class="col-md-4 control-label">Your Subject</label> -->
				<div class="col-md-4 col-sm-4">
					<input type="text" class="form-control" id="subject" name="subject" placeholder="Subject">
				</div>
			</div>
			<br>
			
			<div class="row">
			
				<!-- <label for="the_text" class="col-md-4 control-label">Your Message</label> -->
				<div id="mytextarea" class="col-md-6">
					<textarea class="form-control" name=the_text id="the_text"  placeholder="Type Your Message Here"></textarea>
				</div>
			</div>
			<br>
			
				 <div class="col-sm-offset-3 col-sm-10">
					<button type="submit"id="submit" name="submit" class="btn btn-success">Submit Email</button>
				</div>
			
		</form>
			



			
		</div>
	</div> <!--End of Header -->	
	</div>	
		
		
</section>
	   
	</div>	<!-- End of Container. -->
		
    </div>  <!-- End of Jumbotron. -->  
		
		
	   <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
   <!-- <script src="js/main.js"></script> -->
  </body>
</html>