/* willlyouViewMyAd.js  */


/*

function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}



function getCookie(c_name)
{
var i,x,y,ARRcookies=document.cookie.split(";");
for (i=0;i<ARRcookies.length;i++)
  {
  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
  x=x.replace(/^\s+|\s+$/g,"");
  if (x==c_name)
    {
    return unescape(y);
    }
  }
}

*/

function getCookie( name ) {
  var start = document.cookie.indexOf( name + "=" );
  var len = start + name.length + 1;
  if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) ) {
    return null;
  }
  if ( start == -1 ) return null;
  var end = document.cookie.indexOf( ";", len );
  if ( end == -1 ) end = document.cookie.length;
  return unescape( document.cookie.substring( len, end ) );
}

function setCookie( name, value, expires, path, domain, secure ) {
  var today = new Date();
  today.setTime( today.getTime() );
  if ( expires ) {
    expires = expires * 1000 * 60 * 60 * 24;
  }
  var expires_date = new Date( today.getTime() + (expires) );
  document.cookie = name+"="+escape( value ) +
    ( ( expires ) ? ";expires="+expires_date.toGMTString() : "" ) + //expires.toGMTString()
    ( ( path ) ? ";path=" + path : "" ) +
    ( ( domain ) ? ";domain=" + domain : "" ) +
    ( ( secure ) ? ";secure" : "" );
}

function deleteCookie( name, path, domain ) {
  if ( getCookie( name ) ) document.cookie = name + "=" +
    ( ( path ) ? ";path=" + path : "") +
    ( ( domain ) ? ";domain=" + domain : "" ) +
    ";expires=Thu, 01-Jan-1970 00:00:01 GMT";
}


function init()
{



var itemcodeVar = getCookie('itemcode'); 

//alert(itemcodeVar);
if (!itemcodeVar)
	{
     itemcodeVar = 'Hitchcock';          // set default
	}

switch (itemcodeVar)
{	case 'Hitchcock':
          document.getElementById("option01").style.background = '#C5C653';   // Light Olive  -- Selected Color.
		  document.getElementById("seePicture").innerHTML = '<img src="PaneSize/HitchcockBednightStandsBench.jpg">'; 	  
		  document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbHitchcockBednightStandsBench.jpg">'; 	  
		  document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbHitchcockBureau02.jpg">'; 	  
		  document.getElementById("thumb03").innerHTML = '<img src="ThumbnailPix/ThumbHitchcockBureaunMirror.jpg">'; 	  
		  document.getElementById("thumb04").innerHTML = '<img src="ThumbnailPix/ThumbHitchcockHostestTable.jpg">'; 	  
		  document.getElementById("thumb05").innerHTML = '<img src="ThumbnailPix/ThumbHitchcockRightsidenightstand.jpg">'; 	  
          // --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HitchcockBednightStandsBench.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HitchcockBureau02.jpg">'; 
          }
          document.getElementById("thumb03").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HitchcockBureaunMirror.jpg">'; 
          }
          document.getElementById("thumb04").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HitchcockHostestTable.jpg">'; 
          }
          document.getElementById("thumb05").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HitchcockRightsidenightstand.jpg">'; 
          }
     break;
	
	case 'Oldsmobile':
		  document.getElementById("option02").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		  document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DadscarDiagonalView.jpg">'; 	  
		  document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbDadscarDiagonalView.jpg">'; 	  
		  document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbDadscarFrontView.jpg">'; 	  
		  document.getElementById("thumb03").innerHTML = '<img src="ThumbnailPix/ThumbDadsCarRearView.jpg">'; 	  
		  document.getElementById("thumb04").innerHTML = '<img src="ThumbnailPix/ThumbDadsCarsideview.jpg">'; 	  
     // --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DadscarDiagonalView.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DadscarFrontView.jpg">'; 
          }
          document.getElementById("thumb03").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DadsCarRearView.jpg">'; 
          }
          document.getElementById("thumb04").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DadsCarsideview.jpg">'; 
          }
            
		  break;
    case  'MomsChair':
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DenChair.jpg">'; 	  
		   break;
	case  'DadsRecliner':
		   document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DenDadsRecliner.jpg">'; 	  
		   break;
	case  'DenBureau':
		   document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color. 
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DenBureau.jpg">'; 	  		   
		   break;
	case  'MatchingBeds':
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/TwoMatchingbeds.jpg">'; 	  
		   break;
	case  'BureausNmirror':
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/Twomatchingbureauswithmirror.jpg">'; 	  
		   break;
	case  "KitchenTable":
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/KitchenTable001.jpg">'; 	  
		   document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbKitchenTable001.jpg">'; 	  
		   document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbKitchenTable002.jpg">'; 	  
		   document.getElementById("thumb03").innerHTML = '<img src="ThumbnailPix/ThumbKitchenTable003.jpg">'; 	  
// --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/KitchenTable001.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/KitchenTable002.jpg">'; 
          }
          document.getElementById("thumb03").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/KitchenTable003.jpg">'; 
          }






		   break;
	case  "HutchCupBoard":
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/HutchCupBoard.jpg">'; 	  
           document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbHutchCupboard.jpg">'; 	  
		   document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbHutchCupboard002.jpg">'; 	  		  
           // --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HutchCupboard.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/HutchCupboard002.jpg">'; 
          }


		  break;
	case  "DadsDesk":
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color. 
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DadsDesk.jpg">'; 	  		   
		   document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbDadsDesk.jpg">'; 	  
		   document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbDadsdesk002.jpg">'; 	  
		  // --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DadsDesk.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/Dadsdesk002.jpg">'; 
          }
           break;
	case  "DeskBookcase":
	       document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/DeskBookcase001.jpg">'; 	  
           document.getElementById("thumb01").innerHTML = '<img src="ThumbnailPix/ThumbDeskBookcase001.jpg">'; 	  
		   document.getElementById("thumb02").innerHTML = '<img src="ThumbnailPix/ThumbDeskBookcase002.jpg">'; 	  
		   document.getElementById("thumb03").innerHTML = '<img src="ThumbnailPix/ThumbDeskBookcase003.jpg">'; 	  
           // --------------------------------------------------------------
          // ThumbNail handling.
          document.getElementById("thumb01").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DeskBookcase001.jpg">'; 
          }
          document.getElementById("thumb02").onmouseover = function()
		  {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DeskBookcase002.jpg">'; 
          }
          document.getElementById("thumb03").onmouseover = function()
          {
	         document.getElementById("seePicture").innerHTML = 
	         '<img src="PaneSize/DeskBookcase003.jpg">'; 
          }
		   break;
	case  "OfficeChair":
		   document.getElementById("option03").style.background = '#C5C653';   // Light Olive  -- Selected Color. 
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/OfficeChair.jpg">'; 	  		   
		   break;
	case "Bookcase":
	       document.getElementById("line04X01").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/Bookcase.jpg">'; 	  
		   break;
	case "RecordPlayer":
	       document.getElementById("line04X02").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/RecordPlayer.jpg">'; 	  
		   break;
	case "Records":
	       document.getElementById("line04X03").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		   document.getElementById("seePicture").innerHTML = '<img src="PaneSize/RecordPlayer002.jpg">'; 	  
		   break;
	case "SyFyCollection":
		document.getElementById("line04X04").style.background = '#C5C653';   // Light Olive  -- Selected Color.      		  
		document.getElementById("seePicture").innerHTML = '<img src="PaneSize/MyScienceFictionCollection.jpg">'; 	  
		break;
	default:
		alert("I should not be here. itemcode is not matching anything.");
}


document.getElementById("option01").onmouseover= function() 
{  this.style.background = '#C5C653';   // Light Olive  -- Selected Color. 

//The other three buttons are unselected color.
document.getElementById("option02").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option03").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option04").style.background = '#999933';      // Dark Olive -- UnSelected Color.
// Hide the two drop down menus and the four flyout menus.
document.getElementById("option04dropDown").style.display = 'none'
document.getElementById("option03dropDown").style.display = 'none';
document.getElementById("option03dropFlyoutA").style.display = "none";
document.getElementById("option03dropFlyoutB").style.display = "none";
document.getElementById("option03dropFlyoutC").style.display = "none";
document.getElementById("option03dropFlyoutD").style.display = "none";
}
document.getElementById("option01").onmouseout= function() 
{ this.style.background = '#999933';      // Dark Olive -- UnSelected Color.
}
// --------------------------------------------------------------
// overing over Oldsmobile makes button light olive and turns boot button for Hitchcock
// dark olive.  It also hides the two drop down menus.
document.getElementById("option02").onmouseover= function() 
{  this.style.background = '#C5C653';   // Light Olive  -- Selected Color.
document.getElementById("option01").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option03").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option04").style.background = '#999933';      // Dark Olive -- UnSelected Color.

/* optioncode = 2; */
document.getElementById("option04dropDown").style.display = 'none'
document.getElementById("option03dropDown").style.display = 'none';
document.getElementById("option03dropFlyoutA").style.display = "none";
document.getElementById("option03dropFlyoutB").style.display = "none";
document.getElementById("option03dropFlyoutC").style.display = "none";
document.getElementById("option03dropFlyoutD").style.display = "none";
}

document.getElementById("option02").onmouseout= function() 
{ this.style.background = '#999933'; 
}
// --------------------------------------------------------------
// Hovering over Other Mfg. on the main menu creates this drop down menu of characters.
document.getElementById("option03").onmouseover= function() 
{  this.style.background = '#C5C653';   // Light Olive  -- Selected Color.
document.getElementById("option01").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option02").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option04").style.background = '#999933';      // Dark Olive -- UnSelected Color.


/* optioncode = 3; */
document.getElementById("option03dropDown").style.display = 'block';
document.getElementById("option04dropDown").style.display = 'none'
}

document.getElementById("option03").onmouseout= function() 
{ this.style.background = '#999933';   
  
}

// --------------------------------------------------------------
// The following section relates to what happens when you hover on
// Chairs in the drop down menu of option 3.
// Note that each flyout hides the other three flyouts.

// This flyout is for chairs.
document.getElementById("line03X01").onmouseover = function()
{
	this.style.background = '#C5C653';

	document.getElementById("option03dropFlyoutA").style.display = 'block';
	document.getElementById("option03dropFlyoutB").style.display = 'none';
	document.getElementById("option03dropFlyoutC").style.display = 'none';
	document.getElementById("option03dropFlyoutD").style.display = 'none';
}

document.getElementById("option03dropFlyoutA").onmouseout = function() 
{
	this.style.background = '#999933';
}


document.getElementById("line03X01").onmouseout= function()
{
	this.style.background = '#999933';
}
 
// --------------------------------------------------------------
// This iswhat happens when you hover over Bedroom on Other Mfg menu.
document.getElementById("line03X02").onmouseover = function()
{
	this.style.background = '#C5C653';
	document.getElementById("option03dropFlyoutA").style.display = 'none';
	document.getElementById("option03dropFlyoutB").style.display = 'block';
	document.getElementById("option03dropFlyoutC").style.display = 'none';
	document.getElementById("option03dropFlyoutD").style.display = 'none';
}  /*
document.getElementById("option03dropFlyoutD").style.display = "none";
*/
document.getElementById("line03X02").onmouseout= function()
{
	this.style.background = '#999933';
}

// --------------------------------------------------------------
// This is what happens when you hover over Kitchen on Other Mfg menu.
document.getElementById("line03X03").onmouseover = function()
{
	this.style.background = '#C5C653';
	document.getElementById("option03dropFlyoutA").style.display = 'none';
	document.getElementById("option03dropFlyoutB").style.display = 'none';
	document.getElementById("option03dropFlyoutC").style.display = 'block';
	document.getElementById("option03dropFlyoutD").style.display = 'none';
	
	
	
}  /*
document.getElementById("option03dropFlyoutC").style.display = "none";
*/


document.getElementById("line03X03").onmouseout= function()
{
	this.style.background = '#999933';
}

// --------------------------------------------------------------
// This is what happens when you hover over Office on Other Mfg menu.
document.getElementById("line03X04").onmouseover = function()
{
	this.style.background = '#C5C653';
	document.getElementById("option03dropFlyoutD").style.display = 'block';
	
	document.getElementById("option03dropFlyoutA").style.display = 'none';
	document.getElementById("option03dropFlyoutB").style.display = 'none';
	document.getElementById("option03dropFlyoutC").style.display = 'none';
	document.getElementById("option03dropFlyoutD").style.display = 'block';
	
}


document.getElementById("line03X04").onmouseout= function()
{
	this.style.background = '#999933';
}



// The following sections deal with what happens when you hover on a flyout 
// menu item for sale.

// Chairs menu.
// ------------------------------------------------------------------
// mom's chair
document.getElementById("option03X01AA").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X01AA").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------

//Dad's Chair
document.getElementById("option03X01AB").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X01AB").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}
// ---------------------------------------------------------------------
// 
//Den Bureau.
document.getElementById("option03X02BA").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X02BA").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// 
//Two Matching Twin Beds.
document.getElementById("option03X02BB").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X02BB").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// 
//Two Bureaus with Mirror.
document.getElementById("option03X02BC").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X02BC").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// 
//Table with Chairs.
document.getElementById("option03X03CA").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X03CA").onmouseout = function()
{

	this.style.background = '#CC6699';  // Inactive marroon color
}


// ---------------------------------------------------------------------
// 
//HutchCupBoard.
document.getElementById("option03X03CB").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X03CB").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// Office
//Desk.
document.getElementById("option03X04DA").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X04DA").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// Office

//Desk/Bookcase.
document.getElementById("option03X04DB").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X04DB").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// Office
//Office Chair.
document.getElementById("option03X04DC").onmouseover = function()
{
	this.style.background = '#E6B3CC';  // Active Color.
}

document.getElementById("option03X04DC").onmouseout = function()
{
	this.style.background = '#CC6699';  // Inactive marroon color
}

// ---------------------------------------------------------------------
// tHIS IS FOR THE FOURTH MAIN MENU OPTION, mISC. ITEMS

// --------------------------------------------------------------
// Hovering over Misc. on the main menu creates this drop down menu of items for sale.
document.getElementById("option04").onmouseover= function() 
{  this.style.background = '#C5C653';   // Light Olive  -- Selected Color.
document.getElementById("option02").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option03").style.background = '#999933';      // Dark Olive -- UnSelected Color.
document.getElementById("option01").style.background = '#999933';      // Dark Olive -- UnSelected Color.

/* optioncode = 4; */
  // show OPTION04's drop down menu.
  document.getElementById("option04dropDown").style.display = 'block'

  // When OPTION04 is active all option03 menus (drop down and 4 flyouts) must be hidden.
  document.getElementById("option03dropDown").style.display = 'none';

  document.getElementById("option03dropFlyoutA").style.display = "none";
  document.getElementById("option03dropFlyoutB").style.display = "none";
  document.getElementById("option03dropFlyoutC").style.display = "none";
  document.getElementById("option03dropFlyoutD").style.display = "none";
  }

  // when onmouseout of main menu 04, such as when entering drop down menu
  // then main menu option04 must become inactive color.
document.getElementById("option04").onmouseout= function() 
{ this.style.background = '#999933';   //Dark Olive
}

// ---------------------------------------------------------------
// This is where I handle entering the option04dropDown menu.
// Bookcase


document.getElementById("line04X01").onmouseover = function()
{
	this.style.background = '#C5C653';
}

document.getElementById("line04X01").onmouseout = function()
{
	this.style.background = '#999933';
} 
// --------------------------------------------------------------
// Record Player 

document.getElementById("line04X02").onmouseover = function()
{
	this.style.background = '#C5C653';
}

document.getElementById("line04X02").onmouseout = function()
{
	this.style.background = '#999933';
}

// --------------------------------------------------------------
// Records
document.getElementById("line04X03").onmouseover = function()
{
	this.style.background = '#C5C653';
}

document.getElementById("line04X03").onmouseout = function()
{
	this.style.background = '#999933';
}

// --------------------------------------------------------------
// SyFy Collection
document.getElementById("line04X04").onmouseover = function()
{
	this.style.background = '#C5C653';
}

document.getElementById("line04X04").onmouseout = function()
{
	this.style.background = '#999933';
} 
// ================================================================================================
document.getElementById('option01').onclick = function()
			{	
			setCookie('itemcode', 'Hitchcock', 1);
			window.location.reload()
			}
		  
document.getElementById('option02').onclick = function()
			{	
			setCookie('itemcode', 'Oldsmobile', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X01AA').onclick = function()
			{	
			setCookie('itemcode', 'MomsChair', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X01AB').onclick = function()
			{	
			setCookie('itemcode', 'DadsRecliner', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X02BA').onclick = function()
			{	
			setCookie('itemcode', 'DenBureau', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X02BB').onclick = function()
			{	
			setCookie('itemcode', 'MatchingBeds', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X02BC').onclick = function()
			{	
			setCookie('itemcode', 'BureausNmirror', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X03CA').onclick = function()
			{	
			setCookie('itemcode', 'KitchenTable', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X03CB').onclick = function()
			{	
			setCookie('itemcode', 'HutchCupBoard', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X04DA').onclick = function()
			{	
			setCookie('itemcode', 'DadsDesk', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X04DB').onclick = function()
			{	
			setCookie('itemcode', 'DeskBookcase', 1);
			window.location.reload()
			}
		  
document.getElementById('option03X04DC').onclick = function()
			{	
			setCookie('itemcode', 'OfficeChair', 1);
			window.location.reload()
			}
		  
document.getElementById('line04X01').onclick = function()
			{	
			setCookie('itemcode', 'Bookcase', 1);
			window.location.reload()
			}
		  
document.getElementById('line04X02').onclick = function()
			{	
			setCookie('itemcode', 'RecordPlayer', 1);
			window.location.reload()
			}
		  
document.getElementById('line04X03').onclick = function()
			{	
			setCookie('itemcode', 'Records', 1);
			window.location.reload()
			}
		  
document.getElementById('line04X04').onclick = function()
			{	
			setCookie('itemcode', 'SyFyCollection', 1);
			window.location.reload()
			}
		  




}  // End of init() function.
// ======================================================================



window.onload = init
